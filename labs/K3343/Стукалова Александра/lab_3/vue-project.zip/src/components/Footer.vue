<template>
  <footer class="bg-white text-center py-3 mt-5 shadow-sm">
    <div class="container">
      <p class="mb-0 text-secondary">© 2026 FitnessPlatform.</p>
    </div>
  </footer>
</template>

<script setup>
</script>

<style scoped>
</style>